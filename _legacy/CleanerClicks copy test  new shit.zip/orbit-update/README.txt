Hero orbit update — drop these two files into your repo, replacing the existing ones:

  sections-1.jsx   (added HeroOrbit component + mounted it inside <Hero>)
  styles.css       (added .cc-hero-orbit + .cc-orbit-card styles near the .cc-grid-bg block)

Then:
  git add sections-1.jsx styles.css
  git commit -m "Add spinning orbital background to hero"
  git push
